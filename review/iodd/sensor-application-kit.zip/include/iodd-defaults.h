/* Authored project defaults, applied through the real service. */
#ifndef IODD_DEFAULTS_H
#define IODD_DEFAULTS_H
#define IODD_DEFAULT_THRESHOLD 5000u
#define IODD_DEFAULT_HYSTERESIS 200u
#define IODD_DEFAULT_INVERSION 0u
#endif
