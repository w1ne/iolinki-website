# Authored switching-sensor firmware proof kit

Switching-sensor application MCU execution: authored defaults, threshold/hysteresis, validity, parameter service/readback, byte decoding, inversion and teach. Excludes IO-Link stack/PHY/cable, physical hardware, retained flash, IAR and official conformity.

Actual released sensor C source is unchanged; the generated mapping header binds its parameter indexes/process byte layout. Authored defaults are applied by the real parameter service. The MCU witness checks defaults independently, then applies known vectors for threshold, hysteresis, invalid samples, parameter readback, byte decoding, teach and inversion. Parameters are volatile.

Use the LabWired plugin https://labwired.com: call labwired_compile with labwired.json compile arguments, then labwired_verify with its verify arguments plus firmware_ref from compile. Alternatively store source/files with labwired_put_source first. No shell-execution MCP tool is required. A compile alone is not execution proof; record verify verdict, observed console and any model gaps.

Host cross-check (not MCU proof):

```sh
cc -std=c11 -Wall -Wextra -Werror -DIODD_HOST_PROOF -Iinclude src/main.c src/switching_sensor.c -o proof
./proof
```

GPL-3.0-or-later applies to the firmware implementation and witness; complete corresponding source and license are included. See PROVENANCE.json for upstream source commit and hashes. The IODD JSON/XML are recoverable authored inputs, not official Checker certification.
