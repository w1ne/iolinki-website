# Counter, button and LED — importable IODD example

This package contains stamped iolinki example-reference-device-20261002-IODD1.1.xml, this guide, a generated C firmware mapping header and both MIT/GPL license grants. The iolinki-authored XML templates are additionally available under MIT; this does not change the protocol stack license. Import the ZIP directly into the browser editor or another IODD importer. The examples describe the released [iolinki stack](https://github.com/w1ne/iolinki) applications.

The released reference-device demo produces a 16-bit counter followed by one button/state byte. Output bit 0 drives the LED; preserve the remaining output bits when changing it.

## Identity and use

Vendor ID 1234 and device ID 5678 are example identifiers. Product ID: reference-device. Replace example identity with IDs assigned to your own device before production use. Importing a file does not program the device or change its firmware IDs. A connected device must expose matching identity and process-data lengths.

## Parameters

This counter example has no application ISDU parameters. Standard identification records remain in the IODD.

## Process data

| Direction | Field | Subindex | Bit offset | Width |
| --- | --- | --- | --- | --- |
| Input | Counter | 1 | 8 | 16 |
| Input | Button | 2 | 0 | 8 |
| Output | LED | 1 | 0 | 1 |

Byte 0 is most significant. IODD offset 0 denotes the least-significant bit of the final process-data byte. Use the generated `iodd_read_bits` / `iodd_write_bits` helpers to avoid host endianness or packed-struct assumptions. Input length is 3 bytes; output length is 1 byte.

## Reopen and generate

From the iolinki website source checkout:

```sh
node tools/iodd/cli.mjs import --format package --input downloads/iodd-counter.zip --output counter.project.json
node tools/iodd/cli.mjs inspect --input counter.project.json
node tools/iodd/cli.mjs validate --input counter.project.json
node tools/iodd/cli.mjs export --input counter.project.json --format xml --output counter.xml
node tools/iodd/cli.mjs header --input counter.project.json --output counter-mapping.h
```

The repository's firmware proof compiles and runs the released application C against generated indexes, parameter defaults and bit mappings. That provides host execution evidence; physical IO-Link communication and hardware behavior require a connected-device test. Basic model/CRC validation, official XSD validation and official checker approval are separate results. This package contains no manufacturer declaration.
